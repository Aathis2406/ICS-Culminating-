
public class image {

	public static int getHeight(Object object) {
		// TODO Auto-generated method stub
		return 0;
	}

	public static int getWidth(Object object) {
		// TODO Auto-generated method stub
		return 0;
	}

}
