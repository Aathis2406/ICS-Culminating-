import java.awt.Component;

import javax.swing.Renderer;

public class renderer implements Renderer {

	@Override
	public void setValue(Object aValue, boolean isSelected) {
		// TODO Auto-generated method stub

	}

	@Override
	public Component getComponent() {
		// TODO Auto-generated method stub
		return null;
	}

}
