import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class Menu {

	private String loggedInUser;

	// variable declaration
	JFrame frame = new JFrame();
	Container con;
	JPanel textPanel, inputPanel;
	JLabel textLabel, mainTitle1;
	Font normalFont = new Font("Times New Roman", Font.PLAIN, 26);
	JTextField jtf;
	JButton scoresB, instructionsB, levelsB, PlayB, logoutB, exitB;


	JButton game = new JButton("Begin Game");

	Color blue = new Color(91, 167, 243);

	public Menu(String loggedInUser) {
		this.loggedInUser = loggedInUser;
	}

	private int retrieveHighestScore() {
		// code to retrieve the highest score for the current user from a file or a database
		// using the loggedInUser variable to identify which user's score to retrieve
		// ...
		return retrieveHighestScore();
	}

	public Menu() {

		frame.setUndecorated(false);
		frame.setSize(1300,1000);
		frame.setLocationRelativeTo(null);
		frame.setLayout(null);
		frame.setVisible(true);
		frame.setTitle("Flappy Bird ");
		frame.setResizable(false);



		Icon jpg = new ImageIcon("flappy.jpg");

		frame.getContentPane().setBackground(Color.black);
		con = frame.getContentPane();

		frame.setTitle("Flappy Bird "); 

		mainTitle1 = new JLabel();
		mainTitle1.setText("Main Menu");
		mainTitle1.setFont(new Font("Times New Roman", Font.BOLD, 80));
		mainTitle1.setBounds(445,20,650,650);
		mainTitle1.setForeground(blue);

		inputPanel = new JPanel();
		inputPanel.setBounds(190, 588, 500, 50);
		inputPanel.setBackground(Color.black);
		inputPanel.setLayout(new GridLayout(1,2));



		logoutB = new JButton("Logout & Exit");
		logoutB.setBounds(490, 650, 300, 75);
		logoutB.setFocusable(false);
		logoutB.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		logoutB.setBackground(blue);
		logoutB.setForeground(Color.white);
		logoutB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});



		PlayB = new JButton("Play");
		PlayB.setBounds(490, 410, 300, 75);
		PlayB.setFocusable(false);
		PlayB.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		PlayB.setBackground(blue);
		PlayB.setForeground(Color.white);
		PlayB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// create a new instance of your game class
				Game game = new Game();
				// call the method to start the game
				game.start();
				Game.main(null); 
				frame.dispose();
			}
		});



		instructionsB = new JButton("Instructions");
		instructionsB.setBounds(490, 530, 300, 75);
		instructionsB.setFocusable(false);
		instructionsB.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		instructionsB.setBackground(blue);
		instructionsB.setForeground(Color.white);

		instructionsB.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

			// create new JFrame

			JFrame instructionsFrame = new JFrame("Instructions");

			instructionsFrame.setSize(1250, 700 );

			instructionsFrame.setResizable(false);

			instructionsFrame.setVisible(true);


			// center the frame

			instructionsFrame.setLocationRelativeTo(null);

			// create exit button

			exitB = new JButton("Exit");

			exitB.setBounds(500, 550, 300, 75);

			exitB.setFocusable(false);

			exitB.setFont(new Font("Serif", Font.BOLD, 30));

			exitB.setBackground(blue);

			exitB.setForeground(Color.white);

			exitB.addActionListener(event->{

			instructionsFrame.dispose();

			});

			instructionsFrame.add(exitB);

			JLabel instructionsLabel = new JLabel(" Instructions");

			instructionsLabel.setBounds(350, 2, 1200, 100);

			instructionsLabel.setFont(new Font("Serif",Font.BOLD, 90));

			instructionsFrame.add(instructionsLabel);

			JTextArea instructionsText = new JTextArea();

			instructionsText.setBounds(5, 150, 1200, 500);

			instructionsText.setEditable(false);

			instructionsText.setFont(new Font("Courier New ", Font.BOLD, 24));

			instructionsText.setText(""

			+ "\r\n"

			+ "\r\n"

			+ "\r\n"

			+ "\r\n"

			+ " Flappy Bird is a simple but intense game. As the player you control a bird and must navigate through"

			+ "\r\n"

			+ " approaching pillar obstacles. The game objective is to navigate through as many obstacles as you can"

			+ "\r\n"

			+ " and attain the highest score possible.\r\n"

			+ "\r\n"

			+ " How to play:"

			+ "\r\n"

			+ " 1. Click the screen to make the bird fly.\r\n"

			+ " 2. Avoid touching the approaching obstacles by flying through the gaps.\r\n"

			+ " 3. Score increases each time you pass an obstacle. \r\n"

			+ " 4. The game is over once the bird touches an obstacle. Start again by clicking the screen. \r\n"

			+ " Remember that the key to success in this game is quick reaction and good timing. Keep practicing and"

			+ "\r\n"

			+ " you'll be soaring through the obstacles in no time!");

			instructionsFrame.add(instructionsText);

			}

			});

		frame.add(instructionsB);
		frame.add(PlayB);
		frame.add(logoutB);
		frame.add(mainTitle1);
		

	}


	private void dispose() {
		// TODO Auto-generated method stub

	}









	public void runTitlePage() {
		// TODO Auto-generated method stub

	}





}




