import javax.swing.Icon;

public class gifLabel {

	public static void setBounds(int i, int j, int k, int l) {
		// TODO Auto-generated method stub
		
	}

	public static void setIcon(Icon icon) {
		// TODO Auto-generated method stub
		
	}

}
