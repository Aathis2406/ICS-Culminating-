import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Title implements ActionListener {
    JFrame frame = new JFrame();
    JButton next = new JButton("Start");
    JLabel title;
    String username;
    Color white = new Color(255,255,255);
    Color green = new Color(0, 0, 255);
    Image image;
    
    public Title(String username) {
        this.username = username;
        title = new JLabel("Welcome " + username);
        frame.add(title);
    }
    public Title() {    
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame = new JFrame("Welcome");
        frame.setLayout(new BorderLayout());
        frame.setTitle("Flappy Bird");
        frame.setResizable(false);

        ImageIcon flappy = new ImageIcon("flappy.jpg");
        frame.setIconImage(flappy.getImage());
        frame.setSize(flappy.getIconWidth(), flappy.getIconHeight());
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        Icon jpg = new ImageIcon("flappy.jpg");
    	
	    JLabel jpgLabel = new JLabel(jpg);
	    frame.getContentPane().setBackground(Color.black);
	  
	    frame.getContentPane().add(jpgLabel);

	    frame.pack();
        next.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        next.addActionListener(this);
        next.setBackground(green);

     

        title = new JLabel("Welcome " + username);
        frame.add(next, BorderLayout.SOUTH);

    }


    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == next) {
            Menu menuPage = new Menu();
            frame.dispose();
        }
    }

	public static void runTitlePage() {
		// TODO Auto-generated method stub
		
	}
}
