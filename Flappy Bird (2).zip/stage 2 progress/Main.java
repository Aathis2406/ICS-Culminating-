import java.net.MalformedURLException;

public class Main {
	
	public static void main(String[] args) throws MalformedURLException  {
		
		Title titlePage = new Title();
	
	}
	

}
